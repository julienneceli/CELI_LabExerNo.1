package com.example.celi_labexerno1;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.Nullable;

public class MyService extends IntentService {
    public MyService(){

        super("MyService");
    }
    @Override

    protected void onHandleIntent(@Nullable Intent intent) {
        Log.d("place", "Quadri Square");
        Log.d("place", "Benavides Library");
        Log.d("Place", "UST Grounds");
        Log.d("Place", "Rosarium");
    }
