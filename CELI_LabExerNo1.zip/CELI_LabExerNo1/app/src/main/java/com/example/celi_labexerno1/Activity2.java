

package com.example.celi_labexerno1;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class Activity2 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
    }

    public void displayMsg2(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://www.twenty20.com/photos/44837798"));
        startActivity(i);
    }

    public void displayMsg3(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("http://library.ust.edu.ph/collections.html"));
        startActivity(i);
    }

    public void displayMsg4(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://commons.wikimedia.org/wiki/File:UST_Football_Field.jpg"));
        startActivity(i);
    }

    public void displayMsg5(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://foursquare.com/v/the-rosarium/4fd5fe8e7b0c4fe0bed6621e"));
        startActivity(i);
    }

}
